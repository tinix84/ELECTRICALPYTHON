### EEPOWER PACKAGE INIT FILE
name = "eepower"
ver = "0.0.2"

from .eepower import *