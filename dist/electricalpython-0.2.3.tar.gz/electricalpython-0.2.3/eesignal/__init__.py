### EESIGNAL PACKAGE INIT FILE
name = "eesignal"
ver = "0.1.1"

from .eesignal import *