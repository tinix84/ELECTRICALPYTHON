### EESIGNAL PACKAGE INIT FILE
name = "eesignal"
ver = "0.0.1"

from . import eesignal