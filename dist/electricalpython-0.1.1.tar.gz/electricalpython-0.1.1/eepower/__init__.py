### EEPOWER PACKAGE INIT FILE
name = "eepower"
ver = "0.1.1"

from .eepower import *