### EEPOWER PACKAGE INIT FILE
name = "eepower"
ver = "0.1.2"

from .eepower import *